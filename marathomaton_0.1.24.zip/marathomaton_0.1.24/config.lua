if not marathomaton then marathomaton = {} end
if not marathomaton.config then marathomaton.config = {} end

marathomaton.config.modify_science = true

