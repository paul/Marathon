export FACTORIO_MOD_PATH='/Users/boweiliu/Library/Application Support/factorio'
